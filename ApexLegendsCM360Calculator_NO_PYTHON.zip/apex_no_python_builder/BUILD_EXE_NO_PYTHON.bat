@echo off
setlocal
cd /d "%~dp0"
echo Building ApexLegendsCM360Calculator.exe with built-in Windows .NET compiler...
set CSC=
if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not defined CSC if exist "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not defined CSC (
  echo Could not find csc.exe. This PC may not have .NET Framework compiler enabled.
  echo Try running RUN_PORTABLE_HTML_APP.bat instead. It needs no install and opens the calculator locally.
  pause
  exit /b 1
)
"%CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /out:ApexLegendsCM360Calculator.exe /reference:System.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll ApexLegendsCM360Calculator.cs
if exist ApexLegendsCM360Calculator.exe (
  echo.
  echo DONE: ApexLegendsCM360Calculator.exe was created in this folder.
) else (
  echo Build failed.
)
pause
