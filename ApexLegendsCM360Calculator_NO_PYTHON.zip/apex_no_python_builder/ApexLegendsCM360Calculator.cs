using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace ApexLegendsCM360Calculator
{
    public class MainForm : Form
    {
        TextBox dpiBox, sensBox, cmBox, fovBox;
        RadioButton modeSens, modeCm;
        NumericUpDown mult1, mult2, mult3;
        Label hipOut, oneOut, twoOut, threeOut, sensOut;
        bool updating = false;

        // Apex/source yaw constant calibrated to match reference:
        // 1200 DPI, 0.9 sens = 38.4848 cm/360 hipfire.
        const double APEX_YAW = 0.022;

        // Hidden/engine factors calibrated from the provided reference screenshot:
        // 1200 DPI, 0.9 sens, 1x user optic 1.23 => ~41.62 cm/360.
        // Effective ADS sensitivity = hip sens * user optic mult * hidden factor.
        const double HIDDEN_1X = 0.75187;
        const double HIDDEN_2X = 0.44325;
        const double HIDDEN_3X = 0.29387;

        public MainForm()
        {
            Text = "Apex Legends CM/360 Calculator";
            Width = 980;
            Height = 620;
            MinimumSize = new Size(900, 560);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 10f);
            BackColor = Color.FromArgb(246, 248, 252);

            var title = new Label { Text = "Apex Legends CM/360 Calculator", Font = new Font("Segoe UI", 18f, FontStyle.Bold), AutoSize = true, Left = 24, Top = 18 };
            Controls.Add(title);

            var note = new Label { Text = "Standalone calculator only — no Apex hooks, no overlay, no memory reading, no macros.", AutoSize = true, Left = 26, Top = 58, ForeColor = Color.FromArgb(80, 90, 105) };
            Controls.Add(note);

            var left = new GroupBox { Text = "Inputs", Left = 24, Top = 92, Width = 430, Height = 430, BackColor = Color.White };
            Controls.Add(left);

            modeSens = new RadioButton { Text = "Use in-game sensitivity", Left = 20, Top = 34, Width = 210, Checked = true };
            modeCm = new RadioButton { Text = "Use preferred hipfire cm/360", Left = 230, Top = 34, Width = 190 };
            left.Controls.Add(modeSens); left.Controls.Add(modeCm);

            dpiBox = AddField(left, "Mouse DPI", "1200", 20, 80);
            sensBox = AddField(left, "In-game sensitivity", "0.9", 20, 140);
            cmBox = AddField(left, "Preferred hipfire cm/360", "38.48", 20, 200);
            fovBox = AddField(left, "FOV slider", "110", 20, 260);

            AddMult(left, "1x optic user multiplier", 1.00m, 20, 326, out mult1);
            AddMult(left, "2x optic user multiplier", 1.00m, 155, 326, out mult2);
            AddMult(left, "3x optic user multiplier", 1.00m, 290, 326, out mult3);

            var right = new GroupBox { Text = "Live Results", Left = 480, Top = 92, Width = 460, Height = 430, BackColor = Color.White };
            Controls.Add(right);

            sensOut = AddOutput(right, "Calculated in-game sensitivity", 24, 42);
            hipOut = AddOutput(right, "Hipfire", 24, 104);
            oneOut = AddOutput(right, "1x optic / iron sights", 24, 166);
            twoOut = AddOutput(right, "2x optic", 24, 228);
            threeOut = AddOutput(right, "3x optic", 24, 290);

            var footer = new Label { Left = 24, Top = 535, Width = 920, Height = 45, ForeColor = Color.FromArgb(90, 96, 110),
                Text = "FOV estimate at 110 slider: hipfire 110, 1x about 93.9, 2x about 85.8. The cm/360 outputs use calibrated Apex ADS/optic factors from your reference." };
            Controls.Add(footer);

            foreach (var tb in new[] { dpiBox, sensBox, cmBox, fovBox }) tb.TextChanged += (s, e) => Recalculate();
            modeSens.CheckedChanged += (s, e) => Recalculate();
            modeCm.CheckedChanged += (s, e) => Recalculate();
            mult1.ValueChanged += (s, e) => Recalculate();
            mult2.ValueChanged += (s, e) => Recalculate();
            mult3.ValueChanged += (s, e) => Recalculate();

            Recalculate();
        }

        TextBox AddField(Control parent, string label, string value, int x, int y)
        {
            var l = new Label { Text = label, Left = x, Top = y, Width = 190, Height = 24, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            var t = new TextBox { Text = value, Left = x, Top = y + 24, Width = 180, Height = 28, BorderStyle = BorderStyle.FixedSingle };
            parent.Controls.Add(l); parent.Controls.Add(t);
            return t;
        }

        void AddMult(Control parent, string label, decimal value, int x, int y, out NumericUpDown n)
        {
            var l = new Label { Text = label, Left = x, Top = y, Width = 125, Height = 38, Font = new Font("Segoe UI", 8.2f, FontStyle.Bold) };
            n = new NumericUpDown { DecimalPlaces = 3, Increment = 0.01m, Minimum = 0.01m, Maximum = 10m, Value = value, Left = x, Top = y + 42, Width = 110, Height = 28 };
            parent.Controls.Add(l); parent.Controls.Add(n);
        }

        Label AddOutput(Control parent, string label, int x, int y)
        {
            var l = new Label { Text = label, Left = x, Top = y, Width = 380, Height = 24, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            var v = new Label { Text = "-", Left = x, Top = y + 26, Width = 400, Height = 34, Font = new Font("Consolas", 13f), ForeColor = Color.FromArgb(25, 45, 80) };
            parent.Controls.Add(l); parent.Controls.Add(v);
            return v;
        }

        double Parse(TextBox tb, double fallback)
        {
            double v;
            if (double.TryParse(tb.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return v;
            if (double.TryParse(tb.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out v)) return v;
            return fallback;
        }

        double Cm360(double dpi, double sensitivity)
        {
            if (dpi <= 0 || sensitivity <= 0) return 0;
            return 2.54 * 360.0 / (dpi * sensitivity * APEX_YAW);
        }

        double SensFromCm(double dpi, double cm)
        {
            if (dpi <= 0 || cm <= 0) return 0;
            return 2.54 * 360.0 / (dpi * cm * APEX_YAW);
        }

        double ScopeCm(double dpi, double hipSens, double userMult, double hiddenFactor)
        {
            return Cm360(dpi, hipSens * userMult * hiddenFactor);
        }

        void Recalculate()
        {
            if (updating) return;
            updating = true;
            try
            {
                double dpi = Parse(dpiBox, 1200);
                double hipSens = Parse(sensBox, 0.9);
                double preferredCm = Parse(cmBox, 38.48);

                if (modeCm.Checked)
                {
                    hipSens = SensFromCm(dpi, preferredCm);
                    sensBox.Text = hipSens.ToString("0.######", CultureInfo.InvariantCulture);
                }
                else
                {
                    preferredCm = Cm360(dpi, hipSens);
                    cmBox.Text = preferredCm.ToString("0.##", CultureInfo.InvariantCulture);
                }

                double cHip = Cm360(dpi, hipSens);
                double c1 = ScopeCm(dpi, hipSens, (double)mult1.Value, HIDDEN_1X);
                double c2 = ScopeCm(dpi, hipSens, (double)mult2.Value, HIDDEN_2X);
                double c3 = ScopeCm(dpi, hipSens, (double)mult3.Value, HIDDEN_3X);

                sensOut.Text = hipSens.ToString("0.######", CultureInfo.InvariantCulture);
                hipOut.Text = cHip.ToString("0.00") + " cm/360";
                oneOut.Text = c1.ToString("0.00") + " cm/360   | FOV ≈ " + EstimateFov(1).ToString("0.0");
                twoOut.Text = c2.ToString("0.00") + " cm/360   | FOV ≈ " + EstimateFov(2).ToString("0.0");
                threeOut.Text = c3.ToString("0.00") + " cm/360   | FOV ≈ " + EstimateFov(3).ToString("0.0");
            }
            catch { }
            finally { updating = false; }
        }

        double EstimateFov(int optic)
        {
            double slider = Parse(fovBox, 110);
            double scale = slider / 110.0;
            if (optic == 1) return 93.9 * scale;
            if (optic == 2) return 85.8 * scale;
            return 59.4 * scale;
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
