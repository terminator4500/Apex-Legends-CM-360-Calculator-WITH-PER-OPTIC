@echo off
cd /d "%~dp0"
start "" "%~dp0ApexLegendsCM360Calculator_Portable.html"
